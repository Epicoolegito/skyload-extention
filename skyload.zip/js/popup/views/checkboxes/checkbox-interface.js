/**
 * Skyload - Download manager for media content
 * @link http://skyload.io
 *
 * @version v7.4.0
 *
 * License Agreement:
 * http://skyload.io/eula
 *
 * Privacy Policy:
 * http://skyload.io/privacy-policy
 *
 * Support and FAQ:
 * http://skyload.io/help
 * skyload.extension@gmail.com
 */

"use strict";

define('checkbox_interface_view', ['checkbox_view', 'underscore', 'common'], function (CheckBoxView, _) {
    return CheckBoxView.extend({
        type: null,
        setType: function setType(type) {
            this.type = type;
            return this;
        },
        setLocale: function setLocale(locales) {
            locales = _.extend(locales, { by: Application.getLocale('for') });
            locales = [locales.type, locales.by, locales.domain].join(' ');

            return this.setLabel(locales);
        },
        onCheck: function onCheck() {
            var _this = this;

            if (_.indexOf(Application.AvailableTypes, this.type) >= 0) {
                var domain = Application.App.getModel().getDomain();
                var json = { domain: domain };
                json[this.type] = this.isChecked();

                var save = function save() {
                    return new Promise(function (resolve) {
                        Application.SendMessageFromPopupActionToBackground({
                            method: 'cache',
                            action: 'set',
                            type: 'model',
                            namespace: Application.COLLECTION_TYPE_ACCESS,
                            json: json
                        }, resolve);
                    });
                };

                var find = function find() {
                    return new Promise(function (resolve) {
                        Application.SendMessageFromPopupActionToBackground({
                            method: 'access',
                            action: 'get',
                            domain: domain
                        }, resolve);
                    });
                };

                save().then(function () {
                    return find();
                }).then(function (model) {
                    Application.App.getModel().setAccess(model);

                    Application.SendRequest({
                        method: 'access',
                        access: model
                    });

                    Application.Analytics('Access', [_this.type, _this.isChecked() ? 'show' : 'hide'].join(':'), domain);
                }).catch(function (e) {
                    Application.setLog('Checkbox interface view', 'Save access error', e);
                });
            }

            return this;
        }
    });
});