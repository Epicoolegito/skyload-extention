/**
 * Skyload - Download manager for media content
 * @link http://skyload.io
 *
 * @version v7.4.0
 *
 * License Agreement:
 * http://skyload.io/eula
 *
 * Privacy Policy:
 * http://skyload.io/privacy-policy
 *
 * Support and FAQ:
 * http://skyload.io/help
 * skyload.extension@gmail.com
 */

"use strict";

define('menu_view', ['profile_view', 'backbone', 'browser', 'underscore', 'jquery', 'scrollbar', 'common'], function (ProfileView, Backbone, Browser, _, $) {

    return Backbone.View.extend({
        tagName: 'aside',
        className: 'l-menu m-menu',
        template: _.template($('#template-menu').html()),
        isOpen: false,
        $scrollBar: null,
        $profile: null,
        events: {
            'click .js-logo': 'goToSite',
            'click .js-close': 'close',
            'click .js-menu-item-navigation': 'navigation',
            'click .js-menu-item-lang:not(.m-menu-item-active)': 'locale'
        },
        site: Application.getDetails().homepage_url,
        url: function url(path, term) {
            if (!_.isArray(term)) {
                term = _.isString(term) ? [term] : [];
            }

            term.concat([Browser.platform, Browser.name, Application.getCurrentLocale()]);

            var params = $.param({
                lang: Application.getCurrentLocale(),
                utm_source: Browser.name,
                utm_medium: 'menu',
                utm_content: path,
                utm_term: term.join(','),
                utm_campaign: 'extension'
            });

            return this.site + '/' + (path || '') + '?' + params;
        },
        get siteUrl() {
            return this.url();
        },
        get loginUrl() {
            return this.url('login');
        },
        get loginSiteStateUrl() {
            return this.url('login', 'site_state');
        },
        get donateUrl() {
            return this.url('donate');
        },
        get helpUrl() {
            return this.url('help');
        },
        get helpEmptyStateUrl() {
            return this.url('help', 'empty_state');
        },
        get privacyPolicyUrl() {
            return this.url('privacy-policy');
        },
        get userAgreementUrl() {
            return this.url('user-agreement');
        },
        get vkSupportPageUrl() {
            return this.url('link/vk-support');
        },
        get vkUrl() {
            return this.url('link/vk');
        },
        get facebookUrl() {
            return this.url('link/facebook');
        },
        get downloadYouTubeUrl() {
            return this.helpUrl + '#how-to-download-from-youtube';
        },
        get hashtapUrl() {
            return this.url('link/hashtap');
        },
        goToSite: function goToSite() {
            return Application.OpenTab(this.siteUrl);
        },
        initialize: function initialize() {
            var _this = this;

            Application.App.on('profile_updated', function () {
                return _this.render();
            });
        },
        render: function render() {
            var _this2 = this;

            var args = {
                menu: null,
                social_networks: null,
                hashtap_url: null,
                has_profile: false
            };

            args = {
                menu: {
                    site: Application.getLocale('menu_site'),
                    donate: Application.getLocale('menu_donate'),
                    help: Application.getLocale('menu_help'),
                    vk: Application.getLocale('menu_help_vk'),
                    eula: Application.getLocale('menu_user_agreement'),
                    pp: Application.getLocale('menu_privacy_policy'),
                    login: Application.getLocale('menu_login'),
                    logout: Application.getLocale('menu_logout')
                },
                social_networks: {
                    ht: Application.getLocale('source_name_hashtap'),
                    vk: Application.getLocale('source_name_vk'),
                    fb: Application.getLocale('source_name_fb')
                },
                hashtap_url: this.hashtapUrl,
                has_profile: true
            };

            this.$el.html(this.template(args));

            this.$scrollBar = this.$el.find('.js-menu-scroll-bar');
            this.$profile = this.$el.find('.js-menu-profile');

            this.$scrollBar.scrollBar({
                class_container: 'b-scroll-bar',
                class_scrollbar: 'b-scroll-bar__rail',
                class_track: 'b-scroll-bar__track',
                class_thumb: 'b-scroll-bar__track__thumb',
                class_view_port: 'b-scroll-view-port',
                class_overview: 'b-scroll-view-port__overview',
                class_disable: 'm-scroll-disable',
                class_move: 'm-scroll-move'
            });

            var profile = new ProfileView({ model: Application.App.getProfile() });

            this.$profile.html(profile.render().el);
            this.$profile.find('.js-profile-button').addClass('b-panel__button');

            this.$scrollBar.scrollBarUpdate(0);

            Application.App.on('blanket', function () {
                if (_this2.isOpen) {
                    _this2.close();
                }
            });

            if (Application.App.getProfile().isLogin()) {
                this.$el.addClass('m-menu-profile-login');
            }

            return this;
        },
        openTab: function openTab(url) {
            Application.OpenTab(url).catch(function (e) {
                Application.setLog('Menu', 'Error', e);
            });

            return this;
        },
        control: function control(value) {
            this.isOpen = value;
            Application.App.$el[value ? 'addClass' : 'removeClass']('m-menu-open');

            if (value) {
                this.$scrollBar.scrollBarUpdate(0);
            }

            return this;
        },
        open: function open() {
            Application.Analytics('Menu', 'Open');
            return this.control(true);
        },
        close: function close() {
            return this.control(false);
        },
        login: function login() {
            Application.Analytics('Menu', 'Login');
            return this.openTab(this.loginUrl);
        },
        donate: function donate() {
            Application.Analytics('Menu', 'Donate');
            return this.openTab(this.donateUrl);
        },
        navigation: function navigation(e) {
            var $item = $(e.currentTarget);
            var item = $item.data('item');
            var profile = Application.App.getProfile();

            var data = {
                site: this.site,
                donate: this.donateUrl,
                help: this.helpUrl,
                vk: this.vkSupportPageUrl,
                eula: this.userAgreementUrl,
                pp: this.privacyPolicyUrl,
                login: this.loginUrl,
                vk_page: this.vkUrl,
                fb_page: this.facebookUrl,
                ht_page: this.hashtapUrl
            };

            if (item == 'logout' && profile.isLogin()) {
                Application.Analytics('Menu', 'Logout');

                profile.logout().then(function () {
                    Application.GetSelectedTab().then(function (tab) {
                        return new Promise(function (resolve) {
                            var host = Application.parseURL(tab.url).host;

                            if (host.indexOf('skyload.io') >= 0) {
                                Application.SendMessageFromPopupActionToContent(tab.id, {
                                    method: 'reload'
                                }, function () {
                                    resolve(tab);
                                });
                            } else {
                                resolve(tab);
                            }
                        });
                    }).then(function () {
                        Application.App.reload();
                    }).catch(function (e) {
                        Application.setLog('Menu', 'Reload content page', e);
                        Application.App.reload();
                    });
                }).catch(function (e) {
                    Application.setLog('Menu', 'Logout error', e);
                });
            } else if (item in data) {
                Application.Analytics('Menu navigation', item);
                this.openTab(data[item]);
            }

            return this;
        },
        locale: function locale(e) {
            var $item = $(e.currentTarget);
            var locale = $item.data('locale');

            if (Application.Lang.hasLocale(locale)) {
                Application.Analytics('Locale', locale);

                Application.Lang.setLocale(locale).then(function () {
                    Application.App.reload();
                }).catch(function (e) {
                    Application.setLog('Menu', 'Change locale error', e);
                });
            }

            return this;
        }
    });
});