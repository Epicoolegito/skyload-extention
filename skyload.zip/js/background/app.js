/**
 * Skyload - Download manager for media content
 * @link http://skyload.io
 *
 * @version v7.4.0
 *
 * License Agreement:
 * http://skyload.io/eula
 *
 * Privacy Policy:
 * http://skyload.io/privacy-policy
 *
 * Support and FAQ:
 * http://skyload.io/help
 * skyload.extension@gmail.com
 */

"use strict";

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _gaId = 'UA-44998106-1';

var _gaq = _gaq || [];
_gaq.push(['_setAccount', _gaId]);
_gaq.push(['_trackPageview']);

(function () {
    var ga = document.createElement('script');
    ga.type = 'text/javascript';
    ga.async = true;
    ga.src = 'https://ssl.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(ga, s);
})();

window.onerror = function (message, file, line, col, error) {
    _gaq.push(['_trackEvent', 'Background', 'Window Error', message + ', line: ' + line]);
    Application.setLog('Window', 'Error', message);
};

define(['config', 'common', 'profile', 'tabs', 'lang', 'models', 'collections', 'extension_listener', 'backbone', 'underscore', 'jquery'], function (Config, Application, Profile, Tabs, Lang, Models, Collections, ExtensionListener, Backbone, _, $) {
    window.Application = Application = _.extend(Application, {
        Cache: {},
        Environment: Application.ENVIRONMENT_BACKGROUND,
        CacheNamespace: {
            sound: Application.COLLECTION_TYPE_SOUND,
            video: Application.COLLECTION_TYPE_VIDEO,
            download: Application.COLLECTION_TYPE_DOWNLOAD,
            access: Application.COLLECTION_TYPE_ACCESS
        },
        CacheAction: ['get', 'set'],
        MessageHandler: function MessageHandler(request, sender) {
            return new Promise(function (resolve, reject) {
                try {
                    var method = Application.ExtensionListener[request.method];

                    if (_.isUndefined(method)) {
                        throw new Error('Undefined method (' + request.method + ')');
                    }

                    method(request, sender, resolve);
                } catch (e) {
                    reject(e);
                }
            });
        },
        SendMessageFromContentToBackground: function SendMessageFromContentToBackground(request, callback) {
            this.MessageHandler(request, {}).then(callback, callback);
            return this;
        },
        setAnalytics: function setAnalytics(category, action, label, value) {
            return _gaq.push(['_trackEvent', category, action, label, value]);
        },
        Analytics: function Analytics(category, action, label, value) {
            return this.setAnalytics(category, action, label, value);
        },
        getUrlParam: function getUrlParam() {
            return $.param({
                lang: Application.getCurrentLocale(),
                utm_source: 'background',
                utm_medium: 'cpc',
                utm_content: Application.getVersion(),
                utm_campaign: 'extension'
            });
        },
        getWelcomePageUrl: function getWelcomePageUrl() {
            var url = this.getDetails().homepage_url;
            var param = this.getUrlParam();

            return url + '/welcome?' + param;
        },
        getUninstallUrl: function getUninstallUrl() {
            var url = this.getDetails().homepage_url;
            var param = this.getUrlParam();

            return url + '/uninstall?' + param;
        },
        getExternalWelcomePageUrl: function getExternalWelcomePageUrl() {
            var _this = this;

            return new Promise(function (resolve, reject) {
                var url = _this.getDetails().homepage_url;

                url += '/api/get-welcome-url?' + $.param({
                    'lang': Application.getCurrentLocale()
                });

                Application.Methods.XHR(url, function (_ref) {
                    var response = _ref.response;

                    try {
                        var json = JSON.parse(response.response);

                        if (!json || !json.data || !json.data.url) {
                            throw new Error('Welcome url not set');
                        }

                        resolve(json.data.url);
                    } catch (e) {
                        reject(e);
                    }
                });
            });
        }
    });

    indexedDB.deleteDatabase(Config.DataBase.id);

    Application.Profile = new Profile();
    Application.Tabs = new Tabs();
    Application.Models = new Models();
    Application.Collections = new Collections();
    Application.ExtensionListener = new ExtensionListener();
    Application.Lang = new Lang();
    Application.Notifications = new Application.Collections.Notifications();

    Application.Notifications.on('clicked', function (model) {
        if (model.get('actionType') === Application.NOTIFICATION_TYPE_DOWNLOADING) {
            Application.Cache.Download.off('start_downloading');
        }
    }).on('donate_notification_group', function () {
        Application.Notifications.trigger('show_donate_notification');
    }).on('donate_notification_several', _.after(2, function () {
        Application.Notifications.trigger('show_donate_notification');
    })).once('show_donate_notification', function () {
        Application.Profile.hasSubscription().then(function (has) {
            if (!has) {
                var messages = _.chain([1, 2, 3]).map(function (item) {
                    return {
                        title: 'donate_notification_title_' + item,
                        message: 'donate_notification_message_' + item
                    };
                }).value();

                var message = messages[_.random(0, messages.length - 1)];
                var url = Application.getDetails().homepage_url + '/donate?' + $.param({
                    lang: Application.getCurrentLocale(),
                    utm_source: 'background',
                    utm_medium: 'cpc',
                    utm_content: 'donate',
                    utm_campaign: 'extension',
                    utm_term: [Application.getLocale(messages.title), Application.getLocale(message.message), Application.getCurrentLocale()].join(',')
                });

                var notification = Application.Notifications.add({
                    id: 'donate',
                    title: message.title,
                    message: message.message,
                    history: 'session',
                    url: url
                });

                setTimeout(function () {
                    return notification.show();
                }, 15000);
            }
        }).catch(function (e) {
            return Application.setLog('Background', 'Donate notification', e);
        });
    });

    Application.Cache.Download.on('destroy', function (model) {
        Application.Cache.Download.remove(model);
    }).on('download_error', function (model, e) {
        Application.Notifications.add({
            title: 'notification_error_title',
            message: 'notification_error_message',
            history: 'session',
            actionType: null
        }).show();

        Application.setLog('Background', 'Download error', e);
    }).on('add', function (model) {
        if (model.get('environment') === Application.ENVIRONMENT_CONTENT) {
            Application.Cache.Download.trigger('start_downloading', model);
        }
    }).once('start_downloading', function (model) {
        if (model.get('type') === Application.TYPE_SOUND) {
            Application.Notifications.add({
                id: model.get('index'),
                title: 'download_notification_title',
                message: 'download_notification_message',
                history: 'session',
                actionType: Application.NOTIFICATION_TYPE_DOWNLOADING
            }).show();
        }
    }).on('complete_download', function (model) {
        Application.Notifications.add({
            id: model.get('group').toString(),
            title: 'app_name',
            message: 'g_d_complete',
            history: 'session',
            actionType: Application.NOTIFICATION_TYPE_DOWNLOADS
        }).show();

        Application.Notifications.trigger('donate_notification_group');
    }).on('already_loaded', function () {
        Application.Notifications.add({
            title: 'in_the_queue_3',
            message: 'push_to_icon',
            history: 'session',
            actionType: null
        }).show();
    }).on('change:state', function (model, state) {
        if (state === Application.DOWNLOAD_STATE_COMPLETE && _.isNull(model.get('group'))) {
            Application.Notifications.trigger('donate_notification_several');
        }

        if (state === Application.DOWNLOAD_STATE_COMPLETE && !_.isNull(model.get('group'))) {
            Application.Cache.Download.completeDownload(model);
        }

        if (state === Application.DOWNLOAD_STATE_COMPLETE || state === Application.DOWNLOAD_STATE_INTERRUPTED) {
            model.stopWatchProgress();
        }
    }).on('change:pause', function (model, pause) {
        if (!pause) {
            Application.Notifications.add({
                title: 'the_file_is_loaded',
                message: 'resume_message',
                history: 'session',
                actionType: null
            }).show();
        }
    }).on('change:progress', _.throttle(function (model, progress) {
        Application.SendMessageFromBackgroundToPopupAction({
            action: 'set_download_progress',
            index: model.getIndex(),
            progress: progress,
            download_from: model.get('from')
        });
    }, 300)).on('change:id change:pause change:state change:from change:data', function (model) {
        Application.SendMessageFromBackgroundToPopupAction({
            action: 'update_download',
            index: model.getIndex(),
            model: model.toJSON()
        });
    });

    Application.Cache.Sound.on('change:size change:play change:stream change:stream_create change:duration change:data', function (model) {
        Application.SendMessageFromBackgroundToPopupAction({
            action: 'update_model',
            index: model.getId(),
            model: model.toJSON()
        });
    });

    Application.Cache.Video.on('change:stream change:stream_create change:data', function (model) {
        Application.SendMessageFromBackgroundToPopupAction({
            action: 'update_model',
            index: model.getId(),
            model: model.toJSON()
        });
    }).on('change:size', _.throttle(function (model) {
        Application.SendMessageFromBackgroundToPopupAction({
            action: 'update_model',
            index: model.getId(),
            model: model.toJSON()
        });
    }), 300);

    setInterval(function () {
        Application.Cache.Download.downloadQueue();
        Application.Tabs.Trigger();
    }, 1000);

    Application.OnInstalledListener(function (details) {
        var clear = function clear() {
            Application.Storage('version', Application.getVersion(), 'set', 'local').catch(function (e) {
                Application.setLog('Background', 'Set version error', e);
            });

            sessionStorage.clear();
        };

        Application.SetUninstallURL(Application.getUninstallUrl());

        if (details.reason === 'update' && details.previousVersion !== Application.getVersion()) {
            Application.setAnalytics('Background', 'Update', Application.getVersion());
            clear();
        } else if (details.reason === 'install') {
            Application.setAnalytics('Background', 'Install', Application.getVersion());

            Application.OpenTab(Application.getWelcomePageUrl());

            Application.getExternalWelcomePageUrl().then(function (url) {
                Application.OpenTab(url, false);
            }).catch(function (e) {});

            clear();
        }
    }).OnHeadersReceivedListener(function (details) {
        if (details.tabId === -1) {
            if (details.initiator.includes('deezer.com')) {
                Application.FindFirstTab({ url: '*://*.deezer.com/*' }).then(function (tab) {
                    if (!_.isObject(tab)) {
                        return;
                    }

                    Application.Tabs.ParseRequest(_extends({}, details, {
                        frameId: 0,
                        tabId: tab.id
                    }));
                }).catch(function (e) {
                    Application.setLog('Fist first tab for Deezer', e);
                });
            }

            return;
        }

        if (details.statusCode < 200 || details.statusCode > 400 || details.statusCode === 204) {
            return;
        }

        Application.Tabs.ParseRequest(details);
    }).OnBackgroundMessageListener(function (request, sender, callback) {
        Application.MessageHandler(request, sender).then(callback, callback);
    }).OnCreatedDownloadListener(function (downloadDelta) {
        var id = downloadDelta.id;


        setTimeout(function () {
            var model = Application.Cache.Download.findWhere({ id: id });

            if (model instanceof Backbone.Model) {
                model.startWatchProgress().catch(function (e) {
                    Application.setLog('Background', 'Model download start watch progress error on create', e);
                });
            }
        }, 1000);
    }).OnChangedDownloadListener(function (downloadDelta) {
        var model = Application.Cache.Download.findWhere({ id: downloadDelta.id });

        if (model instanceof Backbone.Model) {
            if ('state' in downloadDelta) {
                model.setState(downloadDelta.state.current);
            } else if ('paused' in downloadDelta) {
                model.setPause(downloadDelta.paused.current);
            } else if ('exists' in downloadDelta) {
                if (downloadDelta.exists.current === false) {
                    model.cancel().catch(function () {
                        Application.Cache.Download.remove(model);
                    });
                }
            } else if ('error' in downloadDelta) {
                model.cancel().catch(function () {
                    Application.Cache.Download.remove(model);
                });
            } else {
                model.startWatchProgress().catch(function (e) {
                    Application.setLog('Background', 'Model download start watch progress error', e);
                });
            }
        }
    }).OnClickedNotificationsListener(function (notificationId) {
        var notifications = Application.Notifications;

        if (notifications instanceof Backbone.Collection) {
            var notification = notifications.get(notificationId);

            if (!_.isUndefined(notification)) {
                notifications.trigger('clicked', notification);
                notification.action();
            }
        }
    }).OnButtonClickedNotificationsListener(function (notificationId) {
        Application.setAnalytics('Notifications', 'Button Clicked', notificationId);
    }).OnClosedNotificationsListener(function (notificationId) {
        Application.setAnalytics('Notifications', 'Closed', notificationId);
    });
});